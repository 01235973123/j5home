<?php
/*
 * ARI Quiz Reloader Joomla! plugin
 *
 * @package		ARI Quiz Reloader Joomla! plugin
 * @version		1.0.0
 * @author		ARI Soft
 * @copyright	Copyright (c) 2009 www.ari-soft.com. All rights reserved
 * @license		GNU/GPL (http://www.gnu.org/copyleft/gpl.html)
 * 
 */

defined('_JEXEC') or die('Restricted access');

jimport('joomla.plugin.plugin');

class plgSystemAriquizreloader extends JPlugin
{ 
	function __construct(&$subject, $config)
	{
		parent::__construct($subject, $config); 
	}
	
	function onAfterDispatch()
	{
		if (!$this->isAriQuizAvailable()) {
			return;
		}

		require_once JPATH_ADMINISTRATOR . '/components/com_ariquiz/kernel/class.AriKernel.php';

		AriKernel::import('Joomla.Compat.Application');

		$document = JFactory::getDocument();
		$doctype = $document->getType();

		if (AriApplication::isAdmin() || $doctype !== 'html') return ;

		$input = AriApplication::getInput();
		
		$option = $input->getCmd('option');
		$task = $input->getString('view');
		
		if ($option != 'com_ariquiz' || $task != 'question') 
			return ;
		
		$document->addScript('plugins/system/ariquizreloader/ariquizreloader/js/init.min.js');
	}

	private function isAriQuizAvailable()
	{
		$quizPath = JPATH_SITE . '/components/com_ariquiz';
		return @file_exists($quizPath); 
	}
}